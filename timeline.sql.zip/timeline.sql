-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 14 oct. 2019 à 22:49
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `timeline`
--

-- --------------------------------------------------------

--
-- Structure de la table `date`
--

DROP TABLE IF EXISTS `date`;
CREATE TABLE IF NOT EXISTS `date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epoque` date NOT NULL,
  `description` varchar(1000) NOT NULL,
  `source` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `date`
--

INSERT INTO `date` (`id`, `epoque`, `description`, `source`) VALUES
(1, '1971-01-01', 'ARPANET connectait 23 mini-ordinateurs dans differentes universites et instituts des Etats-Unis et utilisait le protocole de controle de reseau (NCP) pour transferer des donnees.', 'http://histoire.info.online.fr/net.html'),
(2, '1976-01-01', 'Seymour Cray presente le premier supercalculateur a processeurs vectoriels, le CRAY-1. La machine est refroidie par circulation de freon dans un tube en acier inoxydable colle dans des cales verticales en aluminium entre les piles de cartes de circuits imprimes', ''),
(3, '1974-01-01', 'Ethernet est demontre en mettant en reseau les nouveaux ordinateurs Alto de Xerox PARC.', ''),
(4, '1982-01-01', 'Drew Major et Kyle Powell ecrivent Snipes, un jeu d\'action a jouer sur des ordinateurs PC via le reseau. Ils conditionnent le jeu en tant que \"demo\" pour un logiciel PC de SuperSet Software, Inc. C\'est le debut de Novell.', 'https://fr.wikipedia.org/wiki/Novell'),
(5, '1983-01-01', 'En janvier 1983, TCP / IP devint la methode de communication standard pour ARPANET et remplaça le protocole de controle de reseau (NCP).', 'https://fr.wikipedia.org/wiki/Network_Control_Program_(Arpanet)'),
(6, '1982-01-01', 'Date de création d\'Adobe', ''),
(7, '1987-01-01', 'Date de création d\'Adobe Illustrator', ''),
(8, '1989-01-01', 'Le Web a ete invente par Sir Timothy John \"Tim\" Berners-Lee, ingenieur et informaticien de Great Britin, qui travaille comme professeur au MIT et au laboratoire du CERN.', ''),
(9, '1987-01-01', 'Sortie d\'Android Oreo', ''),
(10, '1987-01-01', 'Premier GIF (nuage qui bouge derrière un avion)', ''),
(11, '1987-01-01', 'GIF a ete mis au point en 1987 par le groupe CompuServe, dirige par l\'informaticien Steve Wilhite (en), pour permettre le téléchargement d\'images en couleur.', ''),
(12, '1990-01-01', 'Sortie d\'Android Pie', ''),
(13, '1990-01-01', 'Les applications mobiles sont apparues dans les années 1991, elles sont liées aux développements d\'Internet et des télécommunications, des réseaux sans fils et des technologies agents2, et à l’apparition et la démocratisation des terminaux mobiles : smartphones, tablettes tactiles.', ''),
(14, '1990-01-01', 'Nous devons à Donald Norman, professeur émérite en sciences cognitives de l\'Université de Californie à San Diego, la première utilisation du terme dans les années 1990, avec la publication de l\'ouvrage The Design of Everyday Things. Norman y développe l\'idée d\'une « conception centrée utilisateur3,4 ».', ''),
(15, '1990-02-19', 'Date de création d\'Adobe Photoshop sur MacOS', ''),
(16, '1991-01-01', 'Le premier navigateur de ligne (www) a été utilise sur le réseau du CERN', ''),
(17, '1992-01-01', 'Le navigateur WWW etait disponible au telechargement via FTP par le CERN. Ce fut le grand depart pour le World Wide Web.', ''),
(18, '1992-01-01', 'Premier site francais cree par le CERN (adresse et photo du groupe + quelques liens)', ''),
(19, '1994-01-01', 'Premier achat réglé via le web (CD de Sting)', ''),
(20, '1994-12-04', 'Le langage Java script a été créé en dix jours en mai 1995 pour le compte de la Netscape Communications Corporation par Brendan Eich', ''),
(21, '1994-12-04', 'Premier spam envoye vers plus de 600 utilisateurs', ''),
(22, '1994-01-01', 'Internet se developpe considerablement depuis qu\'il etait ouvert a un usage commercial. La National Science Foundation a annonce les quatre principaux points d\'acces au reseau suivants: Yahoo, Excite, Infoseek', ''),
(23, '1994-01-01', 'Le langage PHP a été créé en 1994 par Rasmus Lerdorf. C\'était à l\'origine une bibliothèque logicielle en C dont il se servait pour conserver une trace des visiteurs qui venaient consulter son CV.', ''),
(24, '1995-01-01', 'Rasmus a alors décidé, en 1995, de publier son code, pour que tout le monde puisse l\'utiliser et en profiter', ''),
(25, '1996-01-01', 'Le Flash fait son apparition dès 1996 mais il est à son apogée au début des années 2000. C’est une technologie graphique basée sur des images vectorielles animées. L’idée est de proposer des animations autant esthétiques qu’élaborées pouvant interagir avec l’utilisateur.', ''),
(26, '1999-01-01', 'Le protocole WAP (en anglais : Wireless Application Protocol)1 est un protocole de communication apparu en France en 19992 qui permettait d\'accéder à Internet à partir d\'un appareil de transmission sans fil, comme un téléphone mobile ou un assistant personnel.', ''),
(27, '1999-08-31', 'Premier émoticône', ''),
(28, '1999-08-31', 'Création d\'Adobe InDesign', ''),
(29, '2001-01-15', 'Première bannière de publicité', ''),
(30, '2004-11-09', 'première version stable de Firefox', ''),
(31, '2008-01-01', 'Lancement de Spotify', ''),
(32, '2008-01-01', 'En 2008, Steve Jobs annonce l\'App Store, une boutique en ligne pour son iPhone qui bouleverse les règles du jeu.', ''),
(33, '2008-01-01', 'Twitter atteint 1 million d\'utilisateur', ''),
(34, '2008-12-11', 'Google lance son propre browser, fidèle a ses principes : dépouillé et rapide. Chrome connaît un succès fulgurant et taille à la fois des croupières à Firefox et Internet Explorer.', ''),
(35, '2009-04-30', 'Premiere photo mise en ligne sur le net par CERN', ''),
(36, '2010-01-01', '25 ans après son invention, le HTML fait une douce révolution, toujours sous l\'impulsion de Tim Berners-Lee. Grâce à la cinquième version du standard de balisage des pages Web - et de nombreuses technologies associées - de nouveaux services émergent.', ''),
(37, '2010-05-01', 'Le terme de \"Responsive Web design\" a été introduit par Ethan Marcotte dans un article de A List Apart', ''),
(38, '2014-01-01', 'Le milliard de sites dépassés', ''),
(39, '2015-01-01', 'Le projet Spartan, prémisses d’Edge intégré d’abord à Windows 10 uniquement, le nouveau navigateur de Microsoft est disponible sur toutes les versions de Windows depuis février 2018.', ''),
(40, '2016-03-14', 'Version bêta d\'Adobe XD pour les détenteurs d\'un compte Adobe CC sur MacOS', ''),
(41, '2016-12-13', 'Publication de la version bêta d\'adobe XD sur windows10', ''),
(42, '2019-03-01', 'Cette année, le nombre d’utilisateurs mensuels du Web franchit la barre des 4,1 milliards. C’est plus de la moitié de l’humanité qui y accède donc chaque mois, laissant donc encore une marge de progression pour le reste de la planète.', ''),
(43, '2015-12-17', '7eme version de php', ''),
(44, '2006-01-01', 'John Resig lance la bibliothèque JQuery pour faciliter l’écriture des scripts JavaScript', ''),
(45, '1999-01-01', 'Naissance de Napster, premier service d\'échange de fichiers musicaux grâce au format peer to peer', ''),
(46, '1994-07-14', 'création d\'Amazon - Jeff Bezos, pdg', ''),
(47, '1998-09-04', 'Création de Google par Larry Page & Sergey Brin en Californie', ''),
(48, '1976-04-01', 'Création d\'Apple', 'https://fr.wikipedia.org/wiki/Apple'),
(49, '1995-01-01', 'Création du CSS', ''),
(50, '1997-08-29', 'Création de netflix', ''),
(51, '2010-09-07', 'Sketch est un éditeur de graphiques vectoriels développé par la société néerlandaise Bohemian Coding. Sketch a été publié pour la première fois le 7 septembre 2010 sur macOS. 1 Il a remporté un Apple Design Award en 2012. 2 Une différence essentielle entre Sketch et d\'autres éditeurs de graphiques vectoriels est que Sketch n\'inclut pas de fonctionnalités de conception d\'impression.', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
